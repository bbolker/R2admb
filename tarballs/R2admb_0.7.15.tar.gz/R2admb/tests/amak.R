library(R2admb)
xx <- R2admb:::read_tpl("inputs/amak")
