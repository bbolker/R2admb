library(R2admb)
r <- read_pars("inputs/skate")
r <- read_admb("inputs/skate")
setwd("..")
